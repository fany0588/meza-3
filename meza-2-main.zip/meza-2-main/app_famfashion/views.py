from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Cliente, Mujer, Hombre, Ninas, Ninos, Pedido, Reseña
from django.utils import timezone
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib import messages
from decimal import Decimal
# ==========================================
# DECORADOR PARA ADMINISTRADORES
# ==========================================
def admin_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_staff:
            messages.error(request, "Acceso denegado. Se requieren permisos de administrador.")
            return redirect('tienda_inicio')
        return view_func(request, *args, **kwargs)
    return wrapper

# ==========================================
# VISTAS PRINCIPALES
# ==========================================
def inicio_famfashion(request):
    """Página principal - decide redirigir a admin o tienda"""
    if request.user.is_authenticated and request.user.is_staff:
        return redirect('admin_dashboard')  # Redirige al dashboard de admin
    else:
        return redirect('tienda_inicio')    # Redirige a la tienda

def admin_dashboard(request):
    """Dashboard de administración"""
    if not request.user.is_authenticated or not request.user.is_staff:
        return redirect('tienda_inicio')
    
    stats = {
        'total_clientes': Cliente.objects.count(),
        'total_productos': Mujer.objects.count() + Hombre.objects.count() + Ninas.objects.count() + Ninos.objects.count(),
        'pedidos_pendientes': Pedido.objects.filter(estado='pendiente').count(),
        'total_pedidos': Pedido.objects.count(),
    }
    return render(request, 'app_famfashion/admin/dashboard.html', {'stats': stats})

# ==========================================
# VISTAS PARA LA TIENDA CLIENTE
# ==========================================
def tienda_inicio(request):
    """Página principal de la tienda para clientes"""
    productos_destacados = list(Mujer.objects.all()[:4]) + list(Hombre.objects.all()[:4])
    return render(request, 'app_famfashion/tienda/inicio.html', {
        'productos_destacados': productos_destacados
    })

def productos_todos(request):
    """Todos los productos para clientes"""
    productos = {
        'mujer': Mujer.objects.all(),
        'hombre': Hombre.objects.all(),
        'ninas': Ninas.objects.all(),
        'ninos': Ninos.objects.all(),
    }
    return render(request, 'app_famfashion/tienda/productos.html', {'productos': productos})

def productos_por_categoria(request, categoria):
    """Productos por categoría específica para clientes"""
    if categoria == 'mujer':
        productos = Mujer.objects.all()
    elif categoria == 'hombre':
        productos = Hombre.objects.all()
    elif categoria == 'ninas':
        productos = Ninas.objects.all()
    elif categoria == 'ninos':
        productos = Ninos.objects.all()
    else:
        productos = []
    
    return render(request, 'app_famfashion/tienda/categoria.html', {
        'categoria': categoria,
        'productos': productos
    })

def buscar_productos(request):
    """Búsqueda de productos para clientes"""
    query = request.GET.get('q', '')
    if query:
        productos_mujer = Mujer.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
        productos_hombre = Hombre.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
        productos_ninas = Ninas.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
        productos_ninos = Ninos.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
    else:
        productos_mujer = Mujer.objects.none()
        productos_hombre = Hombre.objects.none()
        productos_ninas = Ninas.objects.none()
        productos_ninos = Ninos.objects.none()
    
    return render(request, 'app_famfashion/tienda/buscar.html', {
        'query': query,
        'productos_mujer': productos_mujer,
        'productos_hombre': productos_hombre,
        'productos_ninas': productos_ninas,
        'productos_ninos': productos_ninos,
    })

# ==========================================
# AUTENTICACIÓN Y REGISTRO
# ==========================================
from django.contrib.auth.hashers import make_password

def registro_cliente(request):
    """Registro para clientes (usa el modelo Cliente)"""
    if request.method == 'POST':
        try:
            # Verificar si el email ya existe
            if Cliente.objects.filter(email=request.POST['email']).exists():
                messages.error(request, 'Este email ya está registrado.')
                return render(request, 'app_famfashion/tienda/registro.html')
            
            # Validar que las contraseñas coincidan (si tienes confirmación)
            password = request.POST['password']
            confirm_password = request.POST.get('confirm_password', '')
            
            if confirm_password and password != confirm_password:
                messages.error(request, 'Las contraseñas no coinciden.')
                return render(request, 'app_famfashion/tienda/registro.html')
            
            cliente = Cliente(
                nombre=request.POST['nombre'],
                apellido=request.POST['apellido'],
                email=request.POST['email'],
                telefono=request.POST.get('telefono', ''),
                calle=request.POST.get('calle', ''),
                numero_casa=request.POST.get('numero_casa', ''),
                colonia=request.POST.get('colonia', ''),
                ciudad=request.POST.get('ciudad', ''),
                codigo_postal=request.POST.get('codigo_postal', ''),
                descripcion_direccion=request.POST.get('descripcion_direccion', ''),
                metodo_pago=request.POST.get('metodo_pago', '')
            )
            
            # Encriptar la contraseña antes de guardar
            cliente.contraseña = make_password(password)
            cliente.save()
            
            messages.success(request, '¡Cuenta creada exitosamente! Ahora puedes iniciar sesión.')
            return redirect('login_cliente')
            
        except Exception as e:
            messages.error(request, f'Error al crear la cuenta: {str(e)}')
    
    return render(request, 'app_famfashion/tienda/registro.html')

from django.contrib.auth.hashers import check_password

def login_cliente(request):
    """Login para clientes"""
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        try:
            # Buscar cliente por email
            cliente = Cliente.objects.get(email=email)
            
            # Verificar contraseña usando check_password
            if check_password(password, cliente.contraseña):
                # Contraseña correcta - crear sesión
                request.session['cliente_id'] = cliente.id_cliente  # CAMBIADO: usar id_cliente
                request.session['cliente_nombre'] = f"{cliente.nombre} {cliente.apellido}"
                request.session['cliente_email'] = cliente.email
                
                messages.success(request, f'¡Bienvenido de nuevo, {cliente.nombre}!')
                return redirect('tienda_inicio')
            else:
                messages.error(request, 'Email o contraseña incorrectos.')
                
        except Cliente.DoesNotExist:
            messages.error(request, 'Email o contraseña incorrectos.')
        except Exception as e:
            messages.error(request, f'Error al iniciar sesión: {str(e)}')
    
    return render(request, 'app_famfashion/tienda/login.html')

def logout_cliente(request):
    """Logout para clientes"""
    if 'cliente_id' in request.session:
        nombre = request.session.get('cliente_nombre', '')
        request.session.flush()
        messages.success(request, f'¡Hasta pronto, {nombre}!')
    return redirect('tienda_inicio')

# ==========================================
# CARRITO DE COMPRAS (Sesión-based)
# ==========================================
def ver_carrito(request):
    """Ver carrito usando sesiones - VERSIÓN CORREGIDA CON DECIMAL"""
    carrito = request.session.get('carrito', {})
    items = []
    subtotal = Decimal('0.00')
    
    # Crear una copia del carrito para iterar
    carrito_copia = carrito.copy()
    
    for producto_id, item_data in carrito_copia.items():
        try:
            if item_data['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=item_data['producto_id'])
            else:
                # Tipo inválido, eliminar del carrito real
                if producto_id in carrito:
                    del carrito[producto_id]
                continue
                
            # Usar Decimal para los cálculos
            item_total = producto.precio * Decimal(item_data['cantidad'])
            items.append({
                'producto': producto,
                'cantidad': item_data['cantidad'],
                'tipo': item_data['tipo'],
                'clave': producto_id,
                'total': item_total
            })
            subtotal += item_total
            
        except Exception as e:
            # Producto no existe, eliminar del carrito real
            if producto_id in carrito:
                del carrito[producto_id]
            continue
    
    # Actualizar sesión solo si hubo cambios
    if carrito != request.session.get('carrito', {}):
        request.session['carrito'] = carrito
    
    # Calcular impuestos y total usando Decimal
    tasa_impuestos = Decimal('0.16')  # 16% como Decimal
    impuestos = subtotal * tasa_impuestos
    total = subtotal + impuestos
    
    return render(request, 'app_famfashion/tienda/carrito.html', {
        'items': items,
        'subtotal': subtotal,
        'impuestos': impuestos,
        'total': total
    })

def agregar_al_carrito(request, tipo_producto, id_producto):
    """Agregar producto al carrito (sesión-based)"""
    carrito = request.session.get('carrito', {})
    clave = f"{tipo_producto}_{id_producto}"
    
    if clave in carrito:
        carrito[clave]['cantidad'] += 1
    else:
        carrito[clave] = {
            'tipo': tipo_producto,
            'producto_id': id_producto,
            'cantidad': 1
        }
    
    request.session['carrito'] = carrito
    messages.success(request, 'Producto agregado al carrito.')
    return redirect('ver_carrito')

def actualizar_carrito(request):
    """Actualizar cantidades del carrito - SIN ARGUMENTOS"""
    if request.method == 'POST':
        carrito = request.session.get('carrito', {})
        cambios_realizados = False
        
        for clave, cantidad_str in request.POST.items():
            if clave.startswith('cantidad_'):
                producto_key = clave.replace('cantidad_', '')
                try:
                    nueva_cantidad = int(cantidad_str)
                    if nueva_cantidad > 0 and producto_key in carrito:
                        carrito[producto_key]['cantidad'] = nueva_cantidad
                        cambios_realizados = True
                    elif nueva_cantidad <= 0 and producto_key in carrito:
                        del carrito[producto_key]
                        cambios_realizados = True
                except ValueError:
                    continue
        
        if cambios_realizados:
            request.session['carrito'] = carrito
            messages.success(request, 'Carrito actualizado.')
        else:
            messages.info(request, 'No se realizaron cambios en el carrito.')
    
    return redirect('ver_carrito')
def eliminar_del_carrito(request, producto_key):
    """Eliminar producto del carrito - VERSIÓN CORREGIDA"""
    carrito = request.session.get('carrito', {})
    
    if producto_key in carrito:
        # Obtener nombre del producto antes de eliminar
        try:
            item_data = carrito[producto_key]
            if item_data['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=item_data['producto_id'])
            producto_nombre = producto.nombre_producto
        except:
            producto_nombre = 'Producto'
        
        del carrito[producto_key]
        request.session['carrito'] = carrito
        messages.success(request, f'{producto_nombre} eliminado del carrito.')
    
    return redirect('ver_carrito')
# ==========================================
# CHECKOUT Y PEDIDOS CLIENTES
# ==========================================
def checkout(request):
    """Checkout para clientes - VERSIÓN CORREGIDA CON DECIMAL"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para realizar un pedido.')
        return redirect('login_cliente')
    
    carrito = request.session.get('carrito', {})
    if not carrito:
        messages.warning(request, 'Tu carrito está vacío.')
        return redirect('ver_carrito')
    
    # Calcular totales con Decimal
    subtotal = Decimal('0.00')
    items = []
    
    for producto_key, item_data in carrito.items():
        try:
            if item_data['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=item_data['producto_id'])
            else:
                continue
                
            item_total = producto.precio * Decimal(item_data['cantidad'])
            items.append({
                'producto': producto,
                'cantidad': item_data['cantidad'],
                'tipo': item_data['tipo'],
                'total': item_total
            })
            subtotal += item_total
            
        except Exception as e:
            continue
    
    tasa_impuestos = Decimal('0.16')
    impuestos = subtotal * tasa_impuestos
    total = subtotal + impuestos
    
    if request.method == 'POST':
        try:
            cliente = Cliente.objects.get(id_cliente=request.session['cliente_id'])
            
            # Crear pedido para cada item
            for item in items:
                pedido = Pedido(
                    id_cliente=cliente,
                    nombre_producto=item['producto'].nombre_producto,
                    cantidad=item['cantidad'],
                    precio_unitario=item['producto'].precio,  # Ya es Decimal
                    total=item['total'],  # Ya es Decimal
                    metodo_pago=request.POST.get('metodo_pago', 'Efectivo'),
                    estado='pendiente',
                    direccion=f"{cliente.calle} {cliente.numero_casa}, {cliente.colonia}, {cliente.ciudad}"
                )
                
                # Asignar producto según tipo
                if item['tipo'] == 'mujer':
                    pedido.id_producto_mujer = item['producto']
                elif item['tipo'] == 'hombre':
                    pedido.id_producto_hombre = item['producto']
                elif item['tipo'] == 'ninas':
                    pedido.id_producto_ninas = item['producto']
                elif item['tipo'] == 'ninos':
                    pedido.id_producto_ninos = item['producto']
                
                pedido.save()
            
            # Limpiar carrito
            request.session['carrito'] = {}
            
            messages.success(request, '¡Pedido realizado exitosamente!')
            return redirect('confirmacion_pedido')
            
        except Exception as e:
            messages.error(request, f'Error al procesar el pedido: {str(e)}')
    
    return render(request, 'app_famfashion/tienda/checkout.html', {
        'items': items,
        'subtotal': subtotal,
        'impuestos': impuestos,
        'total': total
    })

def confirmacion_pedido(request):
    """Confirmación de pedido"""
    return render(request, 'app_famfashion/tienda/confirmacion.html')

def mis_pedidos(request):
    """Pedidos del cliente"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para ver tus pedidos.')
        return redirect('login_cliente')
    
    try:
        cliente = Cliente.objects.get(id_cliente=request.session['cliente_id'])
        pedidos = Pedido.objects.filter(id_cliente=cliente).order_by('-fecha_pedido')
        return render(request, 'app_famfashion/tienda/mis_pedidos.html', {'pedidos': pedidos})
    except Cliente.DoesNotExist:
        messages.error(request, 'Cliente no encontrado.')
        return redirect('tienda_inicio')

# ==========================================
# PERFIL CLIENTE
# ==========================================
def perfil_usuario(request):
    """Perfil del cliente"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para acceder a tu perfil.')
        return redirect('login_cliente')
    
    try:
        cliente = Cliente.objects.get(id=request.session['cliente_id'])
        
        if request.method == 'POST':
            cliente.nombre = request.POST['nombre']
            cliente.apellido = request.POST['apellido']
            cliente.email = request.POST['email']
            cliente.telefono = request.POST.get('telefono', '')
            cliente.calle = request.POST.get('calle', '')
            cliente.numero_casa = request.POST.get('numero_casa', '')
            cliente.colonia = request.POST.get('colonia', '')
            cliente.ciudad = request.POST.get('ciudad', '')
            cliente.codigo_postal = request.POST.get('codigo_postal', '')
            cliente.descripcion_direccion = request.POST.get('descripcion_direccion', '')
            cliente.metodo_pago = request.POST.get('metodo_pago', '')
            
            # Actualizar contraseña solo si se proporciona una nueva
            nueva_password = request.POST.get('password', '')
            if nueva_password:
                cliente.contraseña = make_password(nueva_password)  # Encriptar nueva contraseña
            
            cliente.save()
            
            # Actualizar sesión
            request.session['cliente_nombre'] = f"{cliente.nombre} {cliente.apellido}"
            request.session['cliente_email'] = cliente.email
            
            messages.success(request, 'Perfil actualizado exitosamente.')
            return redirect('perfil_usuario')
        
        return render(request, 'app_famfashion/tienda/perfil.html', {'cliente': cliente})
        
    except Cliente.DoesNotExist:
        messages.error(request, 'Cliente no encontrado.')
        return redirect('tienda_inicio')
# ==========================================
# VISTAS PRINCIPALES
# ==========================================
def inicio_famfashion(request):
    return render(request, 'app_famfashion/inicio.html')
# ==========================================
# VISTAS PARA CLIENTES
# ==========================================
def agregar_cliente(request):
    if request.method == 'POST':
        cliente = Cliente(
            nombre=request.POST['nombre'],
            apellido=request.POST['apellido'],
            email=request.POST['email'],
            telefono=request.POST['telefono'],
            calle=request.POST['calle'],
            numero_casa=request.POST['numero_casa'],
            colonia=request.POST['colonia'],
            ciudad=request.POST['ciudad'],
            codigo_postal=request.POST['codigo_postal'],
            descripcion_direccion=request.POST['descripcion_direccion'],
            metodo_pago=request.POST['metodo_pago']
        )
        # Encriptar contraseña
        cliente.contraseña = make_password(request.POST['contraseña'])
        cliente.save()
        return redirect('ver_clientes')
    return render(request, 'app_famfashion/clientes/agregar_cliente.html')

def ver_clientes(request):
    clientes = Cliente.objects.all()
    return render(request, 'app_famfashion/clientes/ver_clientes.html', {'clientes': clientes})

def actualizar_cliente(request, id_cliente):
    cliente = get_object_or_404(Cliente, id=id_cliente)
    if request.method == 'POST':
        cliente.nombre = request.POST['nombre']
        cliente.apellido = request.POST['apellido']
        cliente.email = request.POST['email']
        cliente.telefono = request.POST['telefono']
        cliente.calle = request.POST['calle']
        cliente.numero_casa = request.POST['numero_casa']
        cliente.colonia = request.POST['colonia']
        cliente.ciudad = request.POST['ciudad']
        cliente.codigo_postal = request.POST['codigo_postal']
        cliente.descripcion_direccion = request.POST['descripcion_direccion']
        cliente.metodo_pago = request.POST['metodo_pago']
        
        # Actualizar contraseña solo si se proporciona una nueva
        nueva_password = request.POST.get('contraseña', '')
        if nueva_password:
            cliente.contraseña = make_password(nueva_password)
        
        cliente.save()
        return redirect('ver_clientes')
    return render(request, 'app_famfashion/clientes/actualizar_cliente.html', {'cliente': cliente})

def borrar_cliente(request, id_cliente):
    cliente = get_object_or_404(Cliente, id_cliente=id_cliente)
    if request.method == 'POST':
        cliente.delete()
        return redirect('ver_clientes')
    return render(request, 'app_famfashion/clientes/borrar_cliente.html', {'cliente': cliente})

# ==========================================
# VISTAS PARA PRODUCTOS MUJER
# ==========================================
def agregar_mujer(request):
    if request.method == 'POST':
        mujer = Mujer(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo']
        )
        if 'imagen' in request.FILES:
            mujer.imagen = request.FILES['imagen']
        mujer.save()
        return redirect('ver_mujer')
    return render(request, 'app_famfashion/productos/mujer/agregar_mujer.html')

def ver_mujer(request):
    productos = Mujer.objects.all()
    return render(request, 'app_famfashion/productos/mujer/ver_mujer.html', {'productos': productos})

def actualizar_mujer(request, id_producto):
    producto = get_object_or_404(Mujer, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_mujer')
    return render(request, 'app_famfashion/productos/mujer/actualizar_mujer.html', {'producto': producto})

def borrar_mujer(request, id_producto):
    producto = get_object_or_404(Mujer, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_mujer')
    return render(request, 'app_famfashion/productos/mujer/borrar_mujer.html', {'producto': producto})

# ==========================================
# VISTAS PARA PRODUCTOS HOMBRE
# ==========================================
def agregar_hombre(request):
    if request.method == 'POST':
        hombre = Hombre(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo']
        )
        if 'imagen' in request.FILES:
            hombre.imagen = request.FILES['imagen']
        hombre.save()
        return redirect('ver_hombre')
    return render(request, 'app_famfashion/productos/hombre/agregar_hombre.html')

def ver_hombre(request):
    productos = Hombre.objects.all()
    return render(request, 'app_famfashion/productos/hombre/ver_hombre.html', {'productos': productos})

def actualizar_hombre(request, id_producto):
    producto = get_object_or_404(Hombre, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_hombre')
    return render(request, 'app_famfashion/productos/hombre/actualizar_hombre.html', {'producto': producto})

def borrar_hombre(request, id_producto):
    producto = get_object_or_404(Hombre, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_hombre')
    return render(request, 'app_famfashion/productos/hombre/borrar_hombre.html', {'producto': producto})

# ==========================================
# VISTAS PARA PEDIDOS
# ==========================================
def ver_pedidos(request):
    pedidos = Pedido.objects.all()
    return render(request, 'app_famfashion/pedidos/ver_pedidos.html', {'pedidos': pedidos})

def detalle_pedido(request, id_pedido):
    pedido = get_object_or_404(Pedido, id_pedido=id_pedido)
    return render(request, 'app_famfashion/pedidos/detalle_pedido.html', {'pedido': pedido})

def actualizar_estado_pedido(request, id_pedido):
    pedido = get_object_or_404(Pedido, id_pedido=id_pedido)
    if request.method == 'POST':
        pedido.estado = request.POST['estado']
        pedido.save()
        return redirect('ver_pedidos')
    return render(request, 'app_famfashion/pedidos/actualizar_estado_pedido.html', {'pedido': pedido})

# ==========================================
# VISTAS PARA RESEÑAS
# ==========================================
def ver_resenas(request):
    resenas = Reseña.objects.all()
    return render(request, 'app_famfashion/resenas/ver_resenas.html', {'resenas': resenas})

def agregar_resena(request):
    if request.method == 'POST':
        try:
            # Obtener el primer cliente disponible o crear una reseña sin cliente
            cliente = Cliente.objects.first()  # O puedes hacer un select para que el usuario elija
            
            resena = Reseña(
                id_cliente=cliente,  # Asignar un cliente
                calificacion=request.POST['calificacion'],
                comentario=request.POST['comentario']
            )
            if 'foto_producto' in request.FILES:
                resena.foto_producto = request.FILES['foto_producto']
            resena.save()
            return redirect('ver_resenas')
        except Exception as e:
            print(f"Error al crear reseña: {e}")
            # Manejar el error apropiadamente
    
    # Pasar clientes al template para selección
    clientes = Cliente.objects.all()
    return render(request, 'app_famfashion/resenas/agregar_resena.html', {'clientes': clientes})
def borrar_resena(request, id_reseña):
    resena = get_object_or_404(Reseña, id_reseña=id_reseña)
    if request.method == 'POST':
        resena.delete()
        return redirect('ver_resenas')
    return render(request, 'app_famfashion/resenas/borrar_resena.html', {'resena': resena})

# ==========================================
# VISTAS PARA PRODUCTOS NIÑAS
# ==========================================
def agregar_ninas(request):
    if request.method == 'POST':
        ninas = Ninas(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo'],
            edad_recomendada=request.POST['edad_recomendada']
        )
        if 'imagen' in request.FILES:
            ninas.imagen = request.FILES['imagen']
        ninas.save()
        return redirect('ver_ninas')
    return render(request, 'app_famfashion/productos/ninas/agregar_ninas.html')

def ver_ninas(request):
    productos = Ninas.objects.all()
    return render(request, 'app_famfashion/productos/ninas/ver_ninas.html', {'productos': productos})

def actualizar_ninas(request, id_producto):
    producto = get_object_or_404(Ninas, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        producto.edad_recomendada = request.POST['edad_recomendada']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_ninas')
    return render(request, 'app_famfashion/productos/ninas/actualizar_ninas.html', {'producto': producto})

def borrar_ninas(request, id_producto):
    producto = get_object_or_404(Ninas, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_ninas')
    return render(request, 'app_famfashion/productos/ninas/borrar_ninas.html', {'producto': producto})

# ==========================================
# VISTAS PARA PRODUCTOS NIÑOS
# ==========================================
def agregar_ninos(request):
    if request.method == 'POST':
        ninos = Ninos(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo'],
            edad_recomendada=request.POST['edad_recomendada']
        )
        if 'imagen' in request.FILES:
            ninos.imagen = request.FILES['imagen']
        ninos.save()
        return redirect('ver_ninos')
    return render(request, 'app_famfashion/productos/ninos/agregar_ninos.html')

def ver_ninos(request):
    productos = Ninos.objects.all()
    return render(request, 'app_famfashion/productos/ninos/ver_ninos.html', {'productos': productos})

def actualizar_ninos(request, id_producto):
    producto = get_object_or_404(Ninos, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        producto.edad_recomendada = request.POST['edad_recomendada']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_ninos')
    return render(request, 'app_famfashion/productos/ninos/actualizar_ninos.html', {'producto': producto})

def borrar_ninos(request, id_producto):
    producto = get_object_or_404(Ninos, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_ninos')
    return render(request, 'app_famfashion/productos/ninos/borrar_ninos.html', {'producto': producto})

# ==========================================
# VISTA PARA BORRAR PEDIDO
# ==========================================
def borrar_pedido(request, id_pedido):
    pedido = get_object_or_404(Pedido, id_pedido=id_pedido)
    if request.method == 'POST':
        pedido.delete()
        return redirect('ver_pedidos')
    return render(request, 'app_famfashion/pedidos/borrar_pedido.html', {'pedido': pedido})
def agregar_pedido(request):
    if request.method == 'POST':
        # Obtener el cliente
        cliente_id = request.POST.get('id_cliente')
        cliente = None
        if cliente_id:
            cliente = Cliente.objects.get(id_cliente=cliente_id)
        
        # Calcular total
        cantidad = int(request.POST['cantidad'])
        precio_unitario = float(request.POST['precio_unitario'])
        total = cantidad * precio_unitario
        
        pedido = Pedido(
            id_cliente=cliente,
            nombre_producto=request.POST['nombre_producto'],
            cantidad=cantidad,
            precio_unitario=precio_unitario,
            total=total,
            metodo_pago=request.POST['metodo_pago'],
            estado=request.POST['estado'],
            direccion=request.POST['direccion']
        )
        pedido.save()
        return redirect('ver_pedidos')
    
    # Obtener datos para el formulario
    clientes = Cliente.objects.all()
    productos_mujer = Mujer.objects.all()
    productos_hombre = Hombre.objects.all()
    productos_ninas = Ninas.objects.all()
    productos_ninos = Ninos.objects.all()
    
    context = {
        'clientes': clientes,
        'productos_mujer': productos_mujer,
        'productos_hombre': productos_hombre,
        'productos_ninas': productos_ninas,
        'productos_ninos': productos_ninos,
    }
    return render(request, 'app_famfashion/pedidos/agregar_pedido.html', context)


# ==========================================
# VISTA PARA ACTUALIZAR RESEÑA
# ==========================================
def ver_resenas(request):
    try:
        resenas = Reseña.objects.all()
        # Verificar que todas las reseñas tengan id válido
        for resena in resenas:
            print(f"Reseña ID: {resena.id_reseña}, Cliente: {resena.id_cliente}")
    except Exception as e:
        print(f"Error al cargar reseñas: {e}")
        resenas = []
    
    return render(request, 'app_famfashion/resenas/ver_resenas.html', {'resenas': resenas})

def actualizar_resena(request, id_reseña):  # Asegúrate de que el parámetro sea id_reseña
    resena = get_object_or_404(Reseña, id_reseña=id_reseña)
    if request.method == 'POST':
        resena.calificacion = request.POST['calificacion']
        resena.comentario = request.POST['comentario']
        if 'foto_producto' in request.FILES:
            resena.foto_producto = request.FILES['foto_producto']
        resena.save()
        return redirect('ver_resenas')
    
    clientes = Cliente.objects.all()
    return render(request, 'app_famfashion/resenas/actualizar_resena.html', {
        'resena': resena,
        'clientes': clientes
    })

def admin_dashboard(request):
    """Dashboard de administración"""
    if not request.user.is_authenticated or not request.user.is_staff:
        return redirect('tienda_inicio')
    
    stats = {
        'total_clientes': Cliente.objects.count(),
        'total_productos': Mujer.objects.count() + Hombre.objects.count() + Ninas.objects.count() + Ninos.objects.count(),
        'pedidos_pendientes': Pedido.objects.filter(estado='pendiente').count(),
        'total_pedidos': Pedido.objects.count(),
        'mujer_count': Mujer.objects.count(),
        'hombre_count': Hombre.objects.count(),
        'ninas_count': Ninas.objects.count(),
        'ninos_count': Ninos.objects.count(),
        'total_registros': Cliente.objects.count() + Mujer.objects.count() + Hombre.objects.count() + 
                            Ninas.objects.count() + Ninos.objects.count() + Pedido.objects.count() + 
                            Reseña.objects.count(),
    }
    return render(request, 'app_famfashion/admin/dashboard.html', {'stats': stats})

# ==========================================
# VISTAS PARA FAVORITOS (Sesión-based)
# ==========================================
def ver_favoritos(request):
    """Ver favoritos del cliente"""
    if 'cliente_id' not in request.session:
        messages.info(request, 'Inicia sesión para ver tus favoritos')
        return redirect('login_cliente')
    
    favoritos = request.session.get('favoritos', {})
    productos_favoritos = []
    
    # Reconstruir favoritos desde la sesión
    for clave, datos in favoritos.items():
        try:
            if datos['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=datos['producto_id'])
            else:
                continue
                
            productos_favoritos.append({
                'producto': producto,
                'tipo': datos['tipo'],
                'clave': clave
            })
            
        except Exception as e:
            # Si el producto no existe, remover de favoritos
            continue
    
    return render(request, 'app_famfashion/tienda/favoritos.html', {
        'favoritos': productos_favoritos
    })

def agregar_favorito(request, tipo_producto, id_producto):
    """Agregar producto a favoritos"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para agregar a favoritos')
        return redirect('login_cliente')
    
    favoritos = request.session.get('favoritos', {})
    clave = f"{tipo_producto}_{id_producto}"
    
    try:
        # Verificar que el producto existe
        if tipo_producto == 'mujer':
            producto = Mujer.objects.get(id_producto=id_producto)
        elif tipo_producto == 'hombre':
            producto = Hombre.objects.get(id_producto=id_producto)
        elif tipo_producto == 'ninas':
            producto = Ninas.objects.get(id_producto=id_producto)
        elif tipo_producto == 'ninos':
            producto = Ninos.objects.get(id_producto=id_producto)
        else:
            messages.error(request, 'Tipo de producto no válido')
            return redirect('productos_todos')
        
        if clave not in favoritos:
            favoritos[clave] = {
                'tipo': tipo_producto,
                'producto_id': id_producto,
                'fecha_agregado': timezone.now().isoformat()
            }
            request.session['favoritos'] = favoritos
            messages.success(request, f'"{producto.nombre_producto}" agregado a favoritos')
        else:
            messages.info(request, f'"{producto.nombre_producto}" ya está en tus favoritos')
            
    except Exception as e:
        messages.error(request, 'Error al agregar a favoritos')
    
    # Redirigir a la página anterior
    return redirect(request.META.get('HTTP_REFERER', 'tienda_inicio'))

def eliminar_favorito(request, id_favorito):
    """Eliminar producto de favoritos"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para gestionar favoritos')
        return redirect('login_cliente')
    
    favoritos = request.session.get('favoritos', {})
    
    # id_favorito es la clave del producto en la sesión
    if str(id_favorito) in favoritos:
        producto_nombre = "Producto"  # Podrías obtener el nombre si lo guardas
        del favoritos[str(id_favorito)]
        request.session['favoritos'] = favoritos
        messages.success(request, 'Producto eliminado de favoritos')
    
    return redirect('ver_favoritos')