from django.urls import path
from . import views

urlpatterns = [
    # ==========================================
    # URLs PÚBLICAS Y REDIRECCIONES
    # ==========================================
    path('', views.inicio_famfashion, name='inicio_famfashion'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    
    # ==========================================
    # URLs PARA LA TIENDA CLIENTE
    # ==========================================
    path('tienda/', views.tienda_inicio, name='tienda_inicio'),
    path('productos/', views.productos_todos, name='productos_todos'),
    path('categoria/<str:categoria>/', views.productos_por_categoria, name='productos_categoria'),
    path('buscar/', views.buscar_productos, name='buscar_productos'),

    # Autenticación Cliente
    path('registro/', views.registro_cliente, name='registro_cliente'),
    path('login/', views.login_cliente, name='login_cliente'),
    path('logout/', views.logout_cliente, name='logout_cliente'),

    # Carrito Cliente
    path('carrito/', views.ver_carrito, name='ver_carrito'),
    path('carrito/agregar/<str:tipo_producto>/<int:id_producto>/', views.agregar_al_carrito, name='agregar_carrito'),
    path('carrito/actualizar/', views.actualizar_carrito, name='actualizar_carrito'),
    path('carrito/eliminar/<str:producto_key>/', views.eliminar_del_carrito, name='eliminar_carrito'),

    # Pedidos Cliente
    path('checkout/', views.checkout, name='checkout'),
    path('confirmacion/', views.confirmacion_pedido, name='confirmacion_pedido'),
    path('mis-pedidos/', views.mis_pedidos, name='mis_pedidos'),

    # Perfil Cliente
    path('perfil/', views.perfil_usuario, name='perfil_usuario'),

    #favoritos
    path('favoritos/', views.ver_favoritos, name='ver_favoritos'),
    path('favoritos/agregar/<str:tipo_producto>/<int:id_producto>/', views.agregar_favorito, name='agregar_favorito'),
    path('favoritos/eliminar/<int:id_favorito>/', views.eliminar_favorito, name='eliminar_favorito'),

    # ==========================================
    # URLs DE ADMINISTRACIÓN PERSONALIZADA
    # ==========================================
    
    # Clientes (Admin)
    path('gestion/clientes/agregar/', views.agregar_cliente, name='agregar_cliente'),
    path('gestion/clientes/ver/', views.ver_clientes, name='ver_clientes'),
    path('gestion/clientes/actualizar/<int:id_cliente>/', views.actualizar_cliente, name='actualizar_cliente'),
    path('gestion/clientes/borrar/<int:id_cliente>/', views.borrar_cliente, name='borrar_cliente'),
    
    # Productos Mujer (Admin)
    path('gestion/mujer/agregar/', views.agregar_mujer, name='agregar_mujer'),
    path('gestion/mujer/ver/', views.ver_mujer, name='ver_mujer'),
    path('gestion/mujer/actualizar/<int:id_producto>/', views.actualizar_mujer, name='actualizar_mujer'),
    path('gestion/mujer/borrar/<int:id_producto>/', views.borrar_mujer, name='borrar_mujer'),
    
    # Productos Hombre (Admin)
    path('gestion/hombre/agregar/', views.agregar_hombre, name='agregar_hombre'),
    path('gestion/hombre/ver/', views.ver_hombre, name='ver_hombre'),
    path('gestion/hombre/actualizar/<int:id_producto>/', views.actualizar_hombre, name='actualizar_hombre'),
    path('gestion/hombre/borrar/<int:id_producto>/', views.borrar_hombre, name='borrar_hombre'),
    
    # Productos Niñas (Admin)
    path('gestion/ninas/agregar/', views.agregar_ninas, name='agregar_ninas'),
    path('gestion/ninas/ver/', views.ver_ninas, name='ver_ninas'),
    path('gestion/ninas/actualizar/<int:id_producto>/', views.actualizar_ninas, name='actualizar_ninas'),
    path('gestion/ninas/borrar/<int:id_producto>/', views.borrar_ninas, name='borrar_ninas'),
    
    # Productos Niños (Admin)
    path('gestion/ninos/agregar/', views.agregar_ninos, name='agregar_ninos'),
    path('gestion/ninos/ver/', views.ver_ninos, name='ver_ninos'),
    path('gestion/ninos/actualizar/<int:id_producto>/', views.actualizar_ninos, name='actualizar_ninos'),
    path('gestion/ninos/borrar/<int:id_producto>/', views.borrar_ninos, name='borrar_ninos'),
    
    # Pedidos (Admin)
    path('gestion/pedidos/ver/', views.ver_pedidos, name='ver_pedidos'),
    path('gestion/pedidos/detalle/<int:id_pedido>/', views.detalle_pedido, name='detalle_pedido'),
    path('gestion/pedidos/actualizar/<int:id_pedido>/', views.actualizar_estado_pedido, name='actualizar_estado_pedido'),
    path('gestion/pedidos/borrar/<int:id_pedido>/', views.borrar_pedido, name='borrar_pedido'),
    path('gestion/pedidos/agregar/', views.agregar_pedido, name='agregar_pedido'),
    
    # Reseñas (Admin)
    path('gestion/resenas/ver/', views.ver_resenas, name='ver_resenas'),
    path('gestion/resenas/agregar/', views.agregar_resena, name='agregar_resena'),
    path('gestion/resenas/actualizar/<int:id_reseña>/', views.actualizar_resena, name='actualizar_resena'),
    path('gestion/resenas/borrar/<int:id_reseña>/', views.borrar_resena, name='borrar_resena'),
]